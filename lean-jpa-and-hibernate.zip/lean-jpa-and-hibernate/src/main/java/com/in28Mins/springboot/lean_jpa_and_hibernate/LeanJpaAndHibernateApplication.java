package com.in28Mins.springboot.lean_jpa_and_hibernate;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LeanJpaAndHibernateApplication {

	public static void main(String[] args) {
		SpringApplication.run(LeanJpaAndHibernateApplication.class, args);
	}

}

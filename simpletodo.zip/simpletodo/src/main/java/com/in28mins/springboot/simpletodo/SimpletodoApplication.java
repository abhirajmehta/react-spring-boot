package com.in28mins.springboot.simpletodo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SimpletodoApplication {

	public static void main(String[] args) {
		SpringApplication.run(SimpletodoApplication.class, args);
	}

}

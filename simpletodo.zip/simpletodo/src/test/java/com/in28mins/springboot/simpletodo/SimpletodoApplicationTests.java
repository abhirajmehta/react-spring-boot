package com.in28mins.springboot.simpletodo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SimpletodoApplicationTests {

	@Test
	void contextLoads() {
	}

}
